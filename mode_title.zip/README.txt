Computer Communications submission package
==========================================
VSI: Sustainable Digital Research Infrastructures

Files
-----
compcom_fpga_paper.tex     manuscript source (Elsevier CAS, cas-sc class)
compcom_fpga_paper.pdf     compiled manuscript
refs.bib                   bibliography, 23 entries, publisher-verified
cas-sc.cls                 Elsevier CAS single-column class
cas-common.sty             CAS support package
cas-model2-names.bst       CAS bibliography style
fig/                       8 figures

Figures
-------
fig1_system_architecture.png   Fig. 1(a) system diagram
fig2_application.jpg           Fig. 1(b) measurement setup photograph
fig_quant_range.pdf            Fig. 2 quantisation range allocation
fig_resource_scaling.pdf       Fig. 3 resource scaling
fig_datapath.pdf               Fig. 4 data path bottleneck
fig_energy.pdf                 Fig. 5 energy per flow
fig_power_trace.pdf            Fig. 6 power trace and quality checks
fig_placement.pdf              Fig. 7 placement and idle power
fig_hls_deviation.pdf          Fig. 8 estimator deviation

Build
-----
pdflatex compcom_fpga_paper
bibtex   compcom_fpga_paper
pdflatex compcom_fpga_paper
pdflatex compcom_fpga_paper

Note
----
Highlights are in the frontmatter (\begin{highlights}); Elsevier also
asks for them as a separate editable file at submission.
